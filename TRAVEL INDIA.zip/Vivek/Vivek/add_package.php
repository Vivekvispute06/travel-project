<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $duration = $_POST['duration'];
    $price = $_POST['price'];
    $image = $_POST['image'];

    $query = "INSERT INTO packages (name, description, location, duration, price, image) VALUES ('$name', '$description', '$location', '$duration', '$price', '$image')";
    if (mysqli_query($conn, $query)) {
        echo "Package added successfully!";
        header("Location: admin_dashboard.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Package</title>
    <link rel="stylesheet" href="admin_styles.css">
</head>
<body>
    <header>
        <h1>Add New Travel Package</h1>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <form action="add_package.php" method="POST">
            <label for="name">Package Name:</label>
            <input type="text" id="name" name="name" required><br>

            <label for="description">Description:</label>
            <textarea id="description" name="description" required></textarea><br>

            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required><br>

            <label for="duration">Duration:</label>
            <input type="text" id="duration" name="duration" required><br>

            <label for="price">Price:</label>
            <input type="number" id="price" name="price" required><br>

            <label for="image">Image URL:</label>
            <input type="text" id="image" name="image" required><br>

            <button type="submit">Add Package</button>
        </form>
    </main>

    <footer>
        <p>&copy; 2025 Travel India</p>
    </footer>
</body>
</html>
