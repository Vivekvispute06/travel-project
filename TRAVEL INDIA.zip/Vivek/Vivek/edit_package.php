<?php
include('config.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = mysqli_query($conn, "SELECT * FROM packages WHERE id = '$id'");
    $package = mysqli_fetch_assoc($result);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $duration = $_POST['duration'];
    $price = $_POST['price'];
    $image = $_POST['image'];

    $query = "UPDATE packages SET name='$name', description='$description', location='$location', duration='$duration', price='$price', image='$image' WHERE id='$id'";

    if (mysqli_query($conn, $query)) {
        echo "Package updated successfully!";
        header("Location: admin_dashboard.php");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Package</title>
    <link rel="stylesheet" href="admin_styles.css">
</head>
<body>
    <header>
        <h1>Edit Travel Package</h1>
        <nav>
            <ul>
                <li><a href="admin_dashboard.php">Dashboard</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <form action="edit_package.php?id=<?php echo $package['id']; ?>" method="POST">
            <label for="name">Package Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $package['name']; ?>" required><br>

            <label for="description">Description:</label>
            <textarea id="description" name="description" required><?php echo $package['description']; ?></textarea><br>

            <label for="location">Location:</label>
            <input type="text" id="location" name="location" value="<?php echo $package['location']; ?>" required><br>

            <label for="duration">Duration:</label>
            <input type="text" id="duration" name="duration" value="<?php echo $package['duration']; ?>" required><br>

            <label for="price">Price:</label>
            <input type="number" id="price" name="price" value="<?php echo $package['price']; ?>" required><br>

            <label for="image">Image URL:</label>
            <input type="text" id="image" name="image" value="<?php echo $package['image']; ?>" required><br>

            <button type="submit">Update Package</button>
        </form>
    </main>

    <footer>
        <p>&copy; 2025 Travel India</p>
    </footer>
</body>
</html>
